%%Posizionamento degli autovalori a ciclo chiuso all'interno della regione desiderata
%Regione desiderata Re{autovalori}<=-2

%---------DATI-----------%
%(A,B,C,D) rappresentazione in spazio di stato del sistema in catena aperta
n=3;  %numero di variabili di stato
m=1; %numero di ingressi
p=3; %numero di uscite
A=[2 0 -1;2 1 0;0 0 -1.5];
B=[1; 0; 0];
C=eye(n);
D=zeros(p,m);
%-calcolo autovalori del sistema
eig(A)
%---------------verifica della propriet� strutturale : raggiungibilit�----------%

Mr=ctrb(A,B);
nr=rank(Mr);
%-la coppia (A,B) non � completamente raggiungibile
%-il sottospazio raggiungibile ha dimensione nr=2 
%-il sottospazio non raggiungibile ha dimensione nnr=n-nr=1

nnr=n-nr;
%------------Decomposizione rispetto alla raggiungibilita'----------------%

%
[a b c T k]=ctrbf(A,B,C);

%verifico se gli autovalori del sottospazio non raggiungibile appartengono
%alla regione desiderata Re[autovalori]<=-2


Anr=a(1:nnr,1:nnr);
eig(Anr) 
%il sottospazio non raggiungibile ha un autovalore in -1.5

%-----------Soluzione Hardware--------------------------------------------%

%La soluzione Hardware:aggiungere il numero minimo di attuatori 
%che garantisce il soddisfacimento della propriet� di raggiungibilit�
  
B=[1 0; 0 0; 0 1];  %aggiungo un attuatore (aggiungo una colonna a B)
m=2; %numeri di ingressi
%---------------verifica della propriet� strutturale : raggiungibilit�----------%
Mr=ctrb(A,B);
nr=rank(Mr);
%-la coppia (A,B) � completamente raggiungibile 


%-----------progetto della matrice K del controllore---------------%

K=place(A,B,[-2,-3,-4]);

%----rappresentazione in spazio di stato del sistema a ciclo chiuso------%
%(Ac,Bc,Cc,Dc)

Ac=A-B*K;
Bc=B;
Cc=C;
Dc=zeros(p,m);

sys_c=ss(Ac,Bc,Cc,Dc);
%----- calcolo della risposta del sistema a ciclo chiuso-----%

x0=[2;0;1]; %condizione iniziale 
t=0:0.1:20;
r=ones(length(t),m); %ingresso di riferimento gradino di ampiezza 1 

y= lsim(sys_c,r,t,x0);
figure;
subplot(311),
plot(t,y(:,1)),title('prima componente di y');
grid
subplot(312)
plot(t,y(:,2)),title('seconda componente di y');
grid
subplot(313)
plot(t,y(:,3)),title('terza componente di y');
grid
%-------FINE ESERCIZIO-------------------%




