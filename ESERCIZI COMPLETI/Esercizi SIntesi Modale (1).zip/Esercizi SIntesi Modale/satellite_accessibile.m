J1=1;
J2=1;
k=0.1;
d=0.02;
A=[0 0  1 0;0 0 0 1;-k k -d d;k -k d -d];
n=4; %dimensione stato
B=[0;0;1;0];
p=1; %ingressi
q=n; %variabili misurate
C=eye(q);
D=zeros(q,p);

%variabile controllata è theta_1

P=ss(A,B,C,D);

Mr=ctrb(A,B);

nr=rank(Mr)

%il sistema è raggiungibile


K=place(A,B,[-0.2 -0.3 -0.5 -0.6]);
Ac=A-B*K;
Bc=B;
Cc=C;
Dc=D;

sys=ss(Ac,Bc,Cc,Dc);

%calcolo risposta forzata al gradino (r=1)
figure;
step(sys);
%oppure
[y,t]=step(sys,50);

figure;
plot(t,y(:,1));  %theta_1
grid
