

%STIRRED TANK

A=[-0.01 0;0 -0.02];
B=[1 1;-0.25 0.75];
C=[0.01 0;0 1];
n=2; %dimensione stato
p=2; %ingressi
q=2; %uscite
D=zeros(q,p);

P=ss(A,B,C,D);
%%%%%%%%%%%%%%%%%%%%
t=0:0.1:250;

figure;
step(P,t)

[y t x]=step(P,t);
figure;
plot(t,y(:,1,1)+y(:,1,2)); grid
figure;
plot(t,y(:,2,1)+y(:,2,2)); grid


r1=ones(length(t),1);
r2=r1;
[y1 t x1]=lsim(P,[r1 r2],t,zeros(2,1));
figure;
plot(t,y1(:,1)),grid %1 componente dell'uscita
figure;
plot(t,y1(:,2)),grid %2 componente dell'uscita

%risposta del sistema molto lenta

%%%%%%%%%%%%%%%%%%%

%stato accessibile  x=inv(C)*y

Mr=ctrb(A,B);
nr=rank(Mr)

K=place(A,B,[-0.2 -0.1]);

t=0:0.1:250;
r1=ones(length(t),1);
r2=r1;
sys=ss(A-B*K,B,C,zeros(2));
[y2 t x2]=lsim(sys,[r1 r2],t,zeros(2,1)); %risposta forzata


figure;
plot(t,y2(:,1))
figure
plot(t,y2(:,2))
grid


