A=[-0.01 0;0 -0.02];
B=[1 1;-0.25 0.75];
C=[0.01 0];
n=2; %dimensione stato
p=2; %ingressi
q=1; %uscite
D=zeros(q,p);

P=ss(A,B,C,D);
Mr=ctrb(A,B);
nr=rank(Mr);  %raggiungibile
Mo=obsv(A,C);
no=rank(Mo);  %non osservabile




[a b c T k]=obsvf(A,B,C);

Ano=a(1,1); %il processo e' rilevabile


K=place(A,B,[-0.05 -0.1]);
%Lt=place(A',C',[-0.02 -0.2]); %non funziona
%L=Lt'

Ao=a(2,2);
Co=c(:,2);

L2t=place(Ao',Co',[-0.2]);
L2=L2t';
Lhat=[0;L2];
L=inv(T)*Lhat;

eig(A-L*C)

Ac=[A -B*K;L*C A-B*K-L*C];
Bc=[B;B];
Cc=[C zeros(q,n)];
Dc=D;

sys=ss(Ac,Bc,Cc,Dc);

%calcolo risposta forzata r=gradino
[y,t]=step(sys);
figure;
plot(t,y(:,1))
grid

