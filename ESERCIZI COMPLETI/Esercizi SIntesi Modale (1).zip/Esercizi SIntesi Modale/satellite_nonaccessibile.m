J1=1;
J2=1;
k=0.1;
d=0.02;
A=[0 0  1 0;0 0 0 1;-k k -d d;k -k d -d];
n=4;
B=[0;0;1;0];
p=1; %input
q=2; %output
C=[1 0 0 0;0 1 0 0]; %variabili misurate
D=zeros(q,p);

P=ss(A,B,C,D);

Mr=ctrb(A,B);
Mo=obsv(A,C);
nr=rank(Mr)
no=rank(Mo)

%applico il principio di separazione

K=place(A,B,[-0.2 -0.3 -0.5 -0.6]);
L=place(A',C',[-1 -1.5 -2 -2.5]);
L=L';

Ac=[A -B*K;L*C A-B*K-L*C];
Bc=[B;B];
Cc=[C zeros(q,n)];
Dc=D;

sys=ss(Ac,Bc,Cc,Dc);

%calcolo risposta forzata r=gradino
[y,t]=step(sys,50);
figure;
plot(t,y(:,1))
grid



%simulazione con r gradino e condizione iniziale non nulla
xc0=[2 1 0.5 0.5 2 1 0 0]';
r=ones(length(t),1);
[y1 t x1]=lsim(sys,r,t,xc0);

figure;
plot(t,y1(:,1));grid
figure;
plot(t,y1(:,2));grid


%confronto componente per componente stato vero stato stimato
figure;
plot(t,x1(:,1),'r',t,x1(:,5),'b'); grid
figure;
plot(t,x1(:,2),'r',t,x1(:,6),'b'); grid
figure;
plot(t,x1(:,3),'r',t,x1(:,7),'b'); grid
figure;
plot(t,x1(:,4),'r',t,x1(:,8),'b'); grid


